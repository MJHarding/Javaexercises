/*  @author Russell Martin
 *  @date November 2017
*/
public class For2 {

    public static void main(String[] args)  {
         for (int i = 1; i <= 10; i = i+2)  { 
             System.out.println( i*i );
         }
    }
}
