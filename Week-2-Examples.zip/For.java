/*  @author Russell Martin
 *  @date November 2017
*/
public class For {

    public static void main(String[] args)  {
         for (int i = 1; i <= 10; i++)  { 
             System.out.println( i*i );
         }
    }
}
